# **Tarea 2. Modelo de depreciación de un automóvil**
Un automóvil nuevo tiene un valor inicial de $V_0 = 320000$ pesos. Se estima que cada año pierde el $15\%$ de su valor respecto al año anterior.

Este fenómeno puede modelarse con:

\begin{equation}
    V_{t+1} = V_t(1-D)
\end{equation}

donde:

- $V_t$ es el valor del automóvil en el año $t$,
- $d$ es la tasa de depreciación anual,
- $t$ representa el tiempo en años.

## **Instrucciones**

1. Simula el valor del automóvil durante 15 años.
2. Guarda los resultados en un DataFrame con las columnas:
   - Año
   - Valor del automóvil
3. Grafica el valor del automóvil en función del tiempo.
4. Repite la simulación para tres tasas de depreciación:
   
   \begin{equation}
        d = 0.10, \quad d = 0.15, \quad d = 0.25 
   \end{equation}

5. Grafica los tres escenarios en una misma figura.
6. Responde en texto:
   - ¿Qué representa el parámetro $d$?
   - ¿Qué ocurre con el valor del automóvil cuando aumenta $d$?
   - ¿El valor del automóvil llega exactamente a cero?
   - ¿Después de cuántos años el automóvil vale menos de la mitad de su valor inicial cuando $d = 0.15$?
   - ¿Qué limitaciones tiene este modelo en la vida real?


```python
# Cargar las librerias

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
```


```python
# Datos del problema

V0 = 320000   # Valor inicial del automóvil
d = 0.15     # Tasa de depreciación
t = 15       # Años a simular

valor = [V0]
V_actualizado = V0

for t in range(1, 16):
    V_actualizado = V_actualizado * (1 - d)
    valor.append(V_actualizado)

valor
```




    [320000,
     272000.0,
     231200.0,
     196520.0,
     167042.0,
     141985.69999999998,
     120687.84499999999,
     102584.66824999999,
     87196.96801249999,
     74117.422810625,
     62999.809389031245,
     53549.83798067656,
     45517.36228357507,
     38689.75794103881,
     32886.29424988299,
     27953.350112400538]




```python
# DataFrame de Año y Valor

tiempo = np.arange(0, t + 1)

Pez = pd.DataFrame({
    "Año": tiempo,
    "Valor": valor
})

Pez
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Año</th>
      <th>Valor</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>320000.000000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>272000.000000</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>231200.000000</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>196520.000000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>167042.000000</td>
    </tr>
    <tr>
      <th>5</th>
      <td>5</td>
      <td>141985.700000</td>
    </tr>
    <tr>
      <th>6</th>
      <td>6</td>
      <td>120687.845000</td>
    </tr>
    <tr>
      <th>7</th>
      <td>7</td>
      <td>102584.668250</td>
    </tr>
    <tr>
      <th>8</th>
      <td>8</td>
      <td>87196.968012</td>
    </tr>
    <tr>
      <th>9</th>
      <td>9</td>
      <td>74117.422811</td>
    </tr>
    <tr>
      <th>10</th>
      <td>10</td>
      <td>62999.809389</td>
    </tr>
    <tr>
      <th>11</th>
      <td>11</td>
      <td>53549.837981</td>
    </tr>
    <tr>
      <th>12</th>
      <td>12</td>
      <td>45517.362284</td>
    </tr>
    <tr>
      <th>13</th>
      <td>13</td>
      <td>38689.757941</td>
    </tr>
    <tr>
      <th>14</th>
      <td>14</td>
      <td>32886.294250</td>
    </tr>
    <tr>
      <th>15</th>
      <td>15</td>
      <td>27953.350112</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Gráfica Valor en el Tiempo

plt.plot(Pez["Año"], Pez["Valor"], marker="o", color='green')
plt.xlabel("Año")
plt.ylabel("Valor")
plt.title("Modelo de depreciación de un automóvil")
plt.grid()

plt.show()
```


    
![png](output_4_0.png)
    



```python
V0 = 320000
d_1 = 0.10
d_2 = 0.25
t = 15

valor_1 = [V0]
V_actualizado = V0

# d = 0.10
for t in range(1, 16):
    V_actualizado = V_actualizado * (1 - d_1)
    valor_1.append(V_actualizado)

# valor_1

# DataFrame de Año y Valor con d = 0.10

tiempo_1 = np.arange(0, t + 1)

Luz = pd.DataFrame({
    "Año": tiempo_1,
    "Valor": valor_1
})

valor_2 = [V0]
V_actualizado = V0

# d = 0.25
for t in range(1, 16):
    V_actualizado = V_actualizado * (1 - d_2)
    valor_2.append(V_actualizado)

# valor_2

# DataFrame de Año y Valor con d = 0.25

tiempo_2 = np.arange(0, t + 1)

Garra = pd.DataFrame({
    "Año": tiempo_2,
    "Valor": valor_2
})

Luz
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Año</th>
      <th>Valor</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>320000.000000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>288000.000000</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>259200.000000</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>233280.000000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>209952.000000</td>
    </tr>
    <tr>
      <th>5</th>
      <td>5</td>
      <td>188956.800000</td>
    </tr>
    <tr>
      <th>6</th>
      <td>6</td>
      <td>170061.120000</td>
    </tr>
    <tr>
      <th>7</th>
      <td>7</td>
      <td>153055.008000</td>
    </tr>
    <tr>
      <th>8</th>
      <td>8</td>
      <td>137749.507200</td>
    </tr>
    <tr>
      <th>9</th>
      <td>9</td>
      <td>123974.556480</td>
    </tr>
    <tr>
      <th>10</th>
      <td>10</td>
      <td>111577.100832</td>
    </tr>
    <tr>
      <th>11</th>
      <td>11</td>
      <td>100419.390749</td>
    </tr>
    <tr>
      <th>12</th>
      <td>12</td>
      <td>90377.451674</td>
    </tr>
    <tr>
      <th>13</th>
      <td>13</td>
      <td>81339.706507</td>
    </tr>
    <tr>
      <th>14</th>
      <td>14</td>
      <td>73205.735856</td>
    </tr>
    <tr>
      <th>15</th>
      <td>15</td>
      <td>65885.162270</td>
    </tr>
  </tbody>
</table>
</div>




```python
Garra
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Año</th>
      <th>Valor</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>320000.000000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>240000.000000</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>180000.000000</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>135000.000000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>101250.000000</td>
    </tr>
    <tr>
      <th>5</th>
      <td>5</td>
      <td>75937.500000</td>
    </tr>
    <tr>
      <th>6</th>
      <td>6</td>
      <td>56953.125000</td>
    </tr>
    <tr>
      <th>7</th>
      <td>7</td>
      <td>42714.843750</td>
    </tr>
    <tr>
      <th>8</th>
      <td>8</td>
      <td>32036.132812</td>
    </tr>
    <tr>
      <th>9</th>
      <td>9</td>
      <td>24027.099609</td>
    </tr>
    <tr>
      <th>10</th>
      <td>10</td>
      <td>18020.324707</td>
    </tr>
    <tr>
      <th>11</th>
      <td>11</td>
      <td>13515.243530</td>
    </tr>
    <tr>
      <th>12</th>
      <td>12</td>
      <td>10136.432648</td>
    </tr>
    <tr>
      <th>13</th>
      <td>13</td>
      <td>7602.324486</td>
    </tr>
    <tr>
      <th>14</th>
      <td>14</td>
      <td>5701.743364</td>
    </tr>
    <tr>
      <th>15</th>
      <td>15</td>
      <td>4276.307523</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Simulación con tres tasas de depreciación diferentes
# d=0.10, d=0.15 y d=0.25

V0 = 320000   # Valor inicial del automóvil
# d = 0.15     # Tasa de depreciación
t = 15

depreciaciones = [0.10, 0.15, 0.25]
tiempos = np.arange(0, t+1)

plt.figure(figsize=(8, 5))

for depreciación in depreciaciones:
    V_actualizado = V0
    valor = []
    # Ya pude acomodar todas una sola gráfica
    for t in tiempos:
        valor.append(V_actualizado)
        V_actualizado = V_actualizado * (1 - depreciación)
        
    plt.plot(tiempos, valor, marker="o", markersize=3,
             label=f"depreciación = {depreciación}")
    
    
plt.xlabel("Años")
plt.ylabel("Valor")
plt.title("Modelo de depreciación de un automóvil")
plt.legend()
plt.grid()

plt.show()
```


    
![png](output_7_0.png)
    


### Respuestas 
- *¿Qué representa el parámetro $d$?*

  Representa el porcentaje en con el que se va perdiendo el valor del automovil con forme a los años.
  
- *¿Qué ocurre con el valor del automóvil cuando aumenta $d$?*

    El valor del automóvil disminuye más en menos tiempo, es decir, cada año el automóvil pierde más su valor a través de los años. 
  
- *¿El valor del automóvil llega exactamente a cero?*

    El valor del automóvil pierde su valor y cada vez se va acercando más a cero, pero en 15 años es muy difícil, pero entre más pase
    el tiempo, más se acerca al cero.
  
- *¿Después de cuántos años el automóvil vale menos de la mitad de su valor inicial cuando $d=0.15?*

    Al 5to año, el automóvil ya perdio más de la mitad de su valor (vale menos de la mitad).
  
- *¿Qué limitaciones tiene este modelo en la vida real?*

  El modelo solo podría considerar su valor original, sin tomar en cuenta el desgaste o si tuvo un accidente o si hubo una alteración en el
  automóvil, cuestiones que puedan impactar directamente en su valor, al igual que nuevos modelos y demás cosas, por lo que no mostraría
  su verdadero valor en el tiempo.


```python

```
