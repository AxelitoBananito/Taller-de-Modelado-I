**Tarea 1. Modelo de crecimiento logístico aplicado a usuarios de una aplicación**

Una aplicación nueva tiene inicialmente $P_0 = 250$ usuarios. Se estima que la cantidad máxima de usuarios que podría alcanzar en ese mercado es $K=5000$. 
Supón que la tasa de crecimiento es $r=0.12$ por semana.

El modelo logístico discreto es:

$$P_{t+1} = P_t + rP_t \left(1 - \frac{P_t}{K} \right).$$

**Instrucciones**
1. Simula el crecimiento durante 80 semanas.

2. Guarda los resultados en un DataFrame con las columnas:

    - *Semana*
    - *Usuarios*
3. Grafica la evolución de usuarios en el tiempo.

4. Agrega una línea horizontal que represente la capacidad máxima $K.$

5. Repite la simulación para tres valores de la tasa de crecimiento:

   \begin{equation}
        r=0.05, \quad r=0.12, \quad r=0.25
   \end{equation}

6. Grafica los tres escenarios en una misma figura.

7. Responde en texto:

   - ¿Qué ocurre cuando aumenta $r$?
   - ¿La población de usuarios crece indefinidamente?
   - ¿Qué representa la capacidad de carga $K$ en este problema?


```python
# Cargar las librerias

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
```


```python
# Datos del problema


P0 = 250  #P actualizada a la semana actual 
K = 5000
r = 0.12
semanas = 80   # La tasa de crecimiento es por semana

usuarios = [P0]
P_actualizada = P0

for t in range(1, 81): # Si uso semanas + 1, me marca error en el DataFrame :(
    P_actualizada = P_actualizada + r * P_actualizada * (1 - P_actualizada/K)  
    usuarios.append(P_actualizada)

usuarios
```




    [250,
     278.5,
     310.058506,
     344.9582560685692,
     383.49733803448066,
     425.98733359990956,
     472.75064863059725,
     524.1168902475333,
     580.4181527258114,
     641.9830854845814,
     709.1296409735718,
     782.1564415454251,
     861.332765753652,
     946.8872384434302,
     1038.9954164407932,
     1137.7665910044489,
     1243.2302743504415,
     1355.3229909110191,
     1473.8761399877337,
     1598.6058157616583,
     1729.1055403525693,
     1864.8428619226067,
     2005.1606717613909,
     2149.2838887028715,
     2296.3318457255104,
     2445.3363085159367,
     2595.2645936559366,
     2745.0467854286303,
     2893.6056351794564,
     3039.8874256743757,
     3182.8919432967446,
     3321.699749547474,
     3455.4951780657207,
     3583.5838732183565,
     3705.404176971183,
     3820.5321954545534,
     3928.6808687529847,
     4029.6937721592058,
     4123.534659281222,
     4210.273904323924,
     4290.073020456451,
     4363.168346410865,
     4429.854835521247,
     4490.470683052813,
     4545.383318090588,
     4594.977088060429,
     4639.642792072474,
     4679.769081408449,
     4715.735643450107,
     4747.908016850381,
     4776.633845997096,
     4802.240365947347,
     4825.03290908501,
     4845.2942364051305,
     4863.284515077567,
     4879.241786296638,
     4893.382790832798,
     4905.904042429887,
     4916.983060156756,
     4926.779689442723,
     4935.437457576521,
     4943.084922942118,
     4949.836988365148,
     4955.796157895659,
     4961.053723436417,
     4965.690873125051,
     4969.779717561559,
     4973.384233082876,
     4976.561123535765,
     4979.3606035691555,
     4981.827107508416,
     4983.99992851089,
     4985.913793034679,
     4987.599375761078,
     4989.083760058192,
     4990.390848908141,
     4991.5417309803315,
     4992.555006247137,
     4993.447075227113,
     4994.232395620105,
     4994.923709779446]




```python
# DataFrame Semanas y Usuarios

tiempo = np.arange(0, semanas + 1)

df = pd.DataFrame({
    "Semana": tiempo,
    "Usuarios": usuarios
})

df   # RECORDATORIO: No es necesario llamarlo df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Semana</th>
      <th>Usuarios</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>250.000000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>278.500000</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>310.058506</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>344.958256</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>383.497338</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>76</th>
      <td>76</td>
      <td>4991.541731</td>
    </tr>
    <tr>
      <th>77</th>
      <td>77</td>
      <td>4992.555006</td>
    </tr>
    <tr>
      <th>78</th>
      <td>78</td>
      <td>4993.447075</td>
    </tr>
    <tr>
      <th>79</th>
      <td>79</td>
      <td>4994.232396</td>
    </tr>
    <tr>
      <th>80</th>
      <td>80</td>
      <td>4994.923710</td>
    </tr>
  </tbody>
</table>
<p>81 rows × 2 columns</p>
</div>




```python
# Gráfica Usuarios en el Tiempo

plt.plot(df["Semana"], df["Usuarios"], marker="*", color='blue')
plt.xlabel("Semana")
plt.ylabel("Usuarios")
plt.title("Modelo logístico discreto")
plt.grid()
plt.show()
```


    
![png](output_4_0.png)
    



```python
plt.figure(figsize=(9, 5),dpi=1000)   # Todavía no entiendo bien la escala para la gráfica

plt.plot(df["Semana"], df["Usuarios"], marker="*", color='blue')

#Agregamos la recta del límite de 5000 usuarios

plt.axhline(y=K, linestyle="--", label="Capacidad máxima de usuarios", color ='red')

plt.xlabel("Semana")
plt.ylabel("Usuarios")
plt.title("Modelo logístico discreto")
plt.grid()

plt.show()
```


    
![png](output_5_0.png)
    



```python
# Tasa de crecimeinto para r = 0.05, 0.12, 0.25

P0 = 250 
K = 5000
# r = 0.12

tasas = [0.05, 0.12, 0.25]

for tasa in tasas:
    P_actualizada = P0
    usuarios = [P0]
    semanas = [0]
    for t in range(1,81):
        P_actualizada = P_actualizada + tasa * P_actualizada * (1 - P_actualizada/K)  
        usuarios.append(P_actualizada)
        semanas.append(t)
    plt.figure(figsize=(9, 5),dpi=1000)    # Aquí empiezan las gráficas, no pude ponerlos por separado.
    # Creo no maneje bien las variables, por eso al pasarla me mostraba las gráficas mal posicionadas.

    plt.plot(semanas, usuarios, marker="*", color='blue')

    # Recta de los 5000 usarios
    plt.axhline(y=K, linestyle="--", label=f"Tasa r={tasa}", color ='red')

    plt.xlabel("Semana")
    plt.ylabel("Usuarios")
    plt.title("Modelo logístico discreto")
    plt.grid()

    plt.show()
          
# print("Prueba de usuarios:", usuarios)


# print("\nPrueba de las semanas:", semanas)
```


    
![png](output_6_0.png)
    



    
![png](output_6_1.png)
    



    
![png](output_6_2.png)
    


- *¿Qué ocurre cuando aumenta $r$?*

  Al aumentar el porcentaje de la tasa, el crecimiento de los usuarios crece más rápido en menor tiempo, ya que est directamente proporcional.
  
- *¿La población de usuarios crece indefinidamente?*

    No, llega al tope de 5000 usuarios, independientemente de la tasa de crecimiento, siempre tiende a 5000 usuarios.

- *¿Qué representa la capacidad de carga $K$ en este problema?*

    La capacidad de usuarios finales para la aplicación, podríamos decir que es el "tope" que estimaron para llegar a esa cantidad de usuarios.


```python

```
